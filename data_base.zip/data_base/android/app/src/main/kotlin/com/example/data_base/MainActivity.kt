package com.example.data_base

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
